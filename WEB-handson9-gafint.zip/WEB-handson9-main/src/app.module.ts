import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule.forRoot(),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        type: 'postgres',
        host: configService.get<string>('POSTGRES_HOST'),
        port: configService.get<number>('POSTGRES_PORT')
          ? configService.get<number>('PSTGRES_PORT')
          : 5432,
        password: configService.get<string>('POSTGRES_PASSWORD'),
        database: configService.get<string>('POSTGRES_DATABASE'),
        username: configService.get<string>('POSTGRES_USER'),
        migrations: ['dist/migrations/*js'],
        entities: [__dirname + '/**/*.entity{.ts,.js}'],
        ssl: true,
        autoLoadEntities: true
      })
    })
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
